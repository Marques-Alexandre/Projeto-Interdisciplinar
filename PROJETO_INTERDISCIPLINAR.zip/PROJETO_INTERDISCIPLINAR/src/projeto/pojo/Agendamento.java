package projeto.pojo;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Agendamento {
	private int idAgendamento;
	private Date dataAgendamento;
	private Date horario;
	private double duracao;
	private String cpf;
	private String nomePaciente;
	private String telefone;
	private Date dataNasc;
	private String nomeProfissional;
	private String tipo;
	private double valorConsulta;
	private int porcDesconto;
	private int convenio;
	private int idade;
	

	public int getIdAgendamento() {
		return idAgendamento;
	}
	public void setIdAgendamento(int idAgendamento) {
		this.idAgendamento = idAgendamento;
	}
	public Date getDataAgendamento() {
		String dataformatada = new SimpleDateFormat("dd/MM/yyy").format(dataAgendamento);
		return dataAgendamento;
	}
	public void setDataAgendamento(Date dataAgendamento) {
		this.dataAgendamento = dataAgendamento;
	}
	public Date getHorario() {
		return horario;
	}
	public void setHorario(Date horario) {
		this.horario = horario;
	}
	public double getDuracao() {
		return duracao;
	}
	public void setDuracao(double duracao) {
		this.duracao = duracao;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getNomePaciente() {
		return nomePaciente;
	}
	public void setNomePaciente(String nomePaciente) {
		this.nomePaciente = nomePaciente;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public Date getDataNasc() {
		return dataNasc;
	}
	public void setDataNasc(Date dataNasc) {
		this.dataNasc = dataNasc;
	}
	public String getNomeProfissional() {
		return nomeProfissional;
	}
	public void setNomeProfissional(String nomeProfissional) {
		this.nomeProfissional = nomeProfissional;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public double getValorConsulta() {
		return valorConsulta;
	}
	public void setValorConsulta(double valorConsulta) {
		this.valorConsulta = valorConsulta;
	}
	public int getPorcDesconto() {
		return porcDesconto;
	}
	public void setPorcDesconto(int porcDesconto) {
		this.porcDesconto = porcDesconto;
	}
	public int getConvenio() {
		return convenio;
	}
	public void setConvenio(int convenio) {
		this.convenio = convenio;
	}
	
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public String [] getVetor() {
		String [] v = new String[13];
		v[0] = String.valueOf(idAgendamento);
		v[1] = String.valueOf(dataAgendamento);
		v[2] = String.valueOf(horario);
		v[3] = String.valueOf(duracao);
		v[4] = cpf;
		v[5] = nomePaciente;
		v[6] = telefone;
		v[7] = String.valueOf(dataNasc);
		v[8] = nomeProfissional;
		v[9] = tipo;
		v[10] = String.valueOf(valorConsulta);
		v[11] = String.valueOf(porcDesconto);
		v[12] = String.valueOf(convenio);
		return v;
	}
	public String [] getVetorRelatorio01() {
		String [] v = new String[7];
		v[0] = nomeProfissional;
		v[1] = String.valueOf(dataAgendamento);
		v[2] = String.valueOf(horario);
		v[3] = String.valueOf(duracao);
		v[4] = nomePaciente;
		v[5] = String.valueOf(valorConsulta);
		return v;
	}
	public String [] getVetorRelatorio02() {
		String [] v = new String[5];
		v[0] = nomeProfissional;
		v[1] = String.valueOf(dataAgendamento);
		v[2] = String.valueOf(horario);
		v[3] = String.valueOf(duracao);
		v[4] = nomePaciente;
		return v;
	}
	public String [] getVetorRelatorio04() {
		String [] v = new String[5];
		v[0] = cpf;
		v[1] = nomePaciente;
		v[2] = telefone;
		v[3] = String.valueOf(dataNasc);
		v[4] = String.valueOf(idade);
		return v;
	}
	public String [] getVetorRelatorio05() {
		String [] v = new String[1];
		v[0] = nomeProfissional;
		return v;
	}
	public String [] getVetorRelatorio06() {
		String [] v = new String[1];
		v[0] = String.valueOf(idAgendamento);
		return v;
	}
	public String [] getVetorRelatorio07() {
		String [] v = new String[3];
		v[0] = tipo;
		v[1] = String.valueOf(valorConsulta);
		v[2] = String.valueOf(idAgendamento);
		return v;
	}
	public String [] getVetorRelatorio08() {
		String [] v = new String[2];
		v[0] = nomeProfissional;
		v[1] = String.valueOf(valorConsulta);
		return v;
	}
	public String [] getVetorRelatorio09() {
		String [] v = new String[2];
		v[0] = String.valueOf(idAgendamento);
		v[1] = String.valueOf(valorConsulta);
		return v;
	}
	public String [] getVetorRelatorio10() {
		String [] v = new String[2];
		v[0] = nomeProfissional;
		v[1] = String.valueOf(idAgendamento);
		return v;
	}


	public String toString() {
		return " ID: " + idAgendamento + "\n Data Agendamento: " + dataAgendamento + "\n Horario: " + horario 
				+ "\n Dura��o: " + duracao + "\n CPF: " + cpf + "\n Nome: " + nomePaciente + "\n Telefone: " + telefone + 
				"\n Data Nascimento: " + dataNasc + "\n Nome do Profissional: " + nomeProfissional + "\n Tipo: " + tipo +
				"\n Valor: R$ " + valorConsulta + "\n Desconto: " + porcDesconto + "\n Convenio: " + convenio;
	}

}
