package projeto.db;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import javax.swing.JOptionPane;

import com.sun.net.httpserver.Authenticator.Result;

import projeto.pojo.Agendamento;

public class AgendamentoDao {
	
	public void inserir(Agendamento a) {
		try {
			Conexao con = new Conexao();
			String sql = "INSERT INTO agendamentos(dataAgendamento, horario, duracao, cpf, nomePaciente, telefone, dataNasc, nomeProfissional,"
					+ "tipo, valorConsulta, porcDesconto, convenio) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?)";
			PreparedStatement prep = con.getConexao().prepareStatement(sql);
			prep.setDate(1, new java.sql.Date(a.getDataAgendamento().getTime()));
			prep.setTime(2, new java.sql.Time(a.getHorario().getTime()));
			prep.setDouble(3,  a.getDuracao());
			prep.setString(4, a.getCpf());
			prep.setString(5, a.getNomePaciente());
			prep.setString(6, a.getTelefone());
			prep.setDate(7, new java.sql.Date(a.getDataNasc().getTime()));
			prep.setString(8, a.getNomeProfissional());
			prep.setString(9, a.getTipo());
			prep.setDouble(10, a.getValorConsulta());
			prep.setInt(11, a.getPorcDesconto());
			prep.setInt(12, a.getConvenio());
			prep.execute();
			
			con.getConexao().close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void atualizar(Agendamento a) {
		try {
			Conexao con = new Conexao();
			String sql = "UPDATE agendamentos SET dataAgendamento = ?, horario = ?, duracao = ?, cpf = ?, nomePaciente = ?, telefone = ?, dataNasc = ?, nomeProfissional = ?, tipo = ?, valorConsulta = ?, porcDesconto = ?, convenio = ? WHERE idAgendamento = ?";
			PreparedStatement prep = con.getConexao().prepareStatement(sql);
			prep.setDate(1, new java.sql.Date(a.getDataAgendamento().getTime()));
			prep.setTime(2, new java.sql.Time(a.getHorario().getTime()));
			prep.setDouble(3,  a.getDuracao());
			prep.setString(4, a.getCpf());
			prep.setString(5, a.getNomePaciente());
			prep.setString(6, a.getTelefone());
			prep.setDate(7, new java.sql.Date(a.getDataNasc().getTime()));
			prep.setString(8, a.getNomeProfissional());
			prep.setString(9, a.getTipo());
			prep.setDouble(10, a.getValorConsulta());
			prep.setInt(11, a.getPorcDesconto());
			prep.setInt(12, a.getConvenio());
			prep.setInt(13, a.getIdAgendamento());
			prep.execute();
			
			con.getConexao().close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void excluir(Agendamento a) {
		try {
			Conexao con = new Conexao();
			String sql = "DELETE FROM agendamentos WHERE idAgendamento = ?";
			PreparedStatement prep = con.getConexao().prepareStatement(sql);
			prep.setInt(1, a.getIdAgendamento());
			prep.execute();
			
			con.getConexao().close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public List<Agendamento> listar(){
		List<Agendamento> l = new LinkedList<Agendamento>();
		try {
			Conexao con = new Conexao();
			String sql = "SELECT idAgendamento, dataAgendamento, horario, duracao, cpf, nomePaciente, telefone, dataNasc, nomeProfissional,tipo, valorConsulta, porcDesconto, convenio FROM agendamentos";
			Statement sta = con.getConexao().createStatement();
			ResultSet res = sta.executeQuery(sql);
			while (res.next()) {
				Agendamento a = new Agendamento();
				a.setIdAgendamento(res.getInt("idAgendamento"));
				a.setDataAgendamento(res.getDate("dataAgendamento"));
				a.setHorario(res.getTime("horario"));
				a.setDuracao(res.getDouble("duracao"));
				a.setCpf(res.getString("cpf"));
				a.setNomePaciente(res.getString("nomePaciente"));
				a.setTelefone(res.getString("telefone"));
				a.setDataNasc(res.getDate("dataNasc"));
				a.setNomeProfissional(res.getString("nomeProfissional"));
				a.setTipo(res.getString("tipo"));
				a.setValorConsulta(res.getDouble("valorConsulta"));
				a.setPorcDesconto(res.getInt("porcDesconto"));
				a.setConvenio(res.getInt("convenio"));
				l.add(a);
			}
			res.close();
			con.getConexao().close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return l;
	}
	public Agendamento consultar(int id) {
		Agendamento a = new Agendamento();
		try {
			Conexao con = new Conexao();
			String sql = "SELECT * FROM agendamentos WHERE idAgendamento = " + id;
			Statement sta = con.getConexao().createStatement();
			ResultSet res = sta.executeQuery(sql);
			while (res.next()) {
				a.setDataAgendamento(res.getDate("dataAgendamento"));
				a.setHorario(res.getTime("horario"));
				a.setDuracao(res.getDouble("duracao"));
				a.setCpf(res.getString("cpf"));
				a.setNomePaciente(res.getString("nomePaciente"));
				a.setTelefone(res.getString("telefone"));
				a.setDataNasc(res.getDate("dataNasc"));
				a.setNomeProfissional(res.getString("nomeProfissional"));
				a.setTipo(res.getString("tipo"));
				a.setValorConsulta(res.getDouble("valorConsulta"));
				a.setPorcDesconto(res.getInt("porcDesconto"));
				a.setConvenio(res.getInt("convenio"));
				a.setIdAgendamento(res.getInt("idAgendamento"));
			}
			res.close();
			con.getConexao().close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return a;
	}
	public List<Agendamento> gerarRelatorio1(String nome){
		List<Agendamento> l = new LinkedList<Agendamento>();
		try {
			Conexao con = new Conexao();
			String sql = "SELECT dataAgendamento, horario, duracao, nomePaciente, valorConsulta, nomeProfissional FROM agendamentos WHERE nomeProfissional = '" + nome +"' ORDER BY idAgendamento DESC";
			Statement sta = con.getConexao().createStatement();
			ResultSet res = sta.executeQuery(sql);
			while (res.next()) {
				Agendamento a = new Agendamento();
				a.setDataAgendamento(res.getDate("dataAgendamento"));
				a.setHorario(res.getTime("horario"));
				a.setDuracao(res.getDouble("duracao"));
				a.setNomePaciente(res.getString("nomePaciente"));
				a.setValorConsulta(res.getDouble("valorConsulta"));
				a.setNomeProfissional(res.getString("nomeProfissional"));
				l.add(a);
			}
			res.close();
			con.getConexao().close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return l;
	}
	public List<Agendamento> gerarRelatorio2(Date dataInicial, Date dataFinal){
		DateFormat dt = new SimpleDateFormat("yyyy-MM-dd");
		String dataInicio = dt.format(dataInicial);
		String dataF = dt.format(dataFinal);
		java.sql.Date dataIni =  null;
		try {
			dataIni = new java.sql.Date(dt.parse(dataInicio).getTime());
		} catch (Exception e) {
			e.printStackTrace();
		}
		java.sql.Date dataFim = null;
		try {
			dataFim = new java.sql.Date(dt.parse(dataF).getTime());
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<Agendamento> l = new LinkedList<Agendamento>();
		try {
			Conexao con = new Conexao();
			String sql = "SELECT nomeProfissional, dataAgendamento, horario, duracao, nomePaciente FROM agendamentos WHERE dataAgendamento >= '"+ dataIni+"' AND dataAgendamento <= '"+dataFim + "' ORDER BY nomeProfissional";
			Statement sta = con.getConexao().createStatement();
			ResultSet res = sta.executeQuery(sql);
			while (res.next()) {
				Agendamento a = new Agendamento();
				a.setNomeProfissional(res.getString("nomeProfissional"));
				a.setDataAgendamento(res.getDate("dataAgendamento"));
				a.setHorario(res.getTime("horario"));
				a.setDuracao(res.getDouble("duracao"));
				a.setNomePaciente(res.getString("nomePaciente"));
				l.add(a);
			}
			res.close();
			con.getConexao().close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return l;
	}
	public List<Agendamento> gerarRelatorio3(String tipo, Date dataInicial, Date dataFinal){
		DateFormat dt = new SimpleDateFormat("yyyy-MM-dd");
		String dataInicio = dt.format(dataInicial);
		String dataF = dt.format(dataFinal);
		java.sql.Date dataIni =  null;
		try {
			dataIni = new java.sql.Date(dt.parse(dataInicio).getTime());
		} catch (Exception e) {
			e.printStackTrace();
		}
		java.sql.Date dataFim = null;
		try {
			dataFim = new java.sql.Date(dt.parse(dataF).getTime());
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<Agendamento> l = new LinkedList<Agendamento>();
		try {
			Conexao con = new Conexao();
			String sql = "SELECT nomeProfissional, dataAgendamento, horario, duracao, nomePaciente FROM agendamentos WHERE tipo = '" + tipo + "' AND dataAgendamento >= '"+ dataIni+"' AND dataAgendamento <= '"+dataFim + "'"
					+ " ORDER BY dataAgendamento, horario ASC";
			Statement sta = con.getConexao().createStatement();
			ResultSet res = sta.executeQuery(sql);
			while (res.next()) {
				Agendamento a = new Agendamento();
				a.setNomeProfissional(res.getString("nomeProfissional"));
				a.setDataAgendamento(res.getDate("dataAgendamento"));
				a.setHorario(res.getTime("horario"));
				a.setDuracao(res.getDouble("duracao"));
				a.setNomePaciente(res.getString("nomePaciente"));
				l.add(a);
			}
			res.close();
			con.getConexao().close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return l;
	}
	public List<Agendamento> gerarRelatorio4(int mes){
		List<Agendamento> l = new LinkedList<Agendamento>();
		try {
			Conexao con = new Conexao();
			String sql = "SELECT cpf, nomePaciente, telefone, dataNasc, TIMESTAMPDIFF(YEAR, dataNasc, NOW()) as 'idade' FROM agendamentos WHERE MONTH(dataNasc)  = " + mes;
			Statement sta = con.getConexao().createStatement();
			ResultSet res = sta.executeQuery(sql);
			while (res.next()) {
				Agendamento a = new Agendamento();
				a.setCpf(res.getString("cpf"));
				a.setNomePaciente(res.getString("nomePaciente"));
				a.setTelefone(res.getString("telefone"));
				a.setDataNasc(res.getDate("dataNasc"));
				a.setIdade(res.getInt("idade"));
				l.add(a);
			}
			res.close();
			con.getConexao().close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return l;
	}
	public Agendamento gerarRelatorio5(String nome){
		Agendamento a = new Agendamento();
		try {
			Conexao con = new Conexao();
			String sql = "SELECT nomeProfissional FROM agendamentos WHERE nomeProfissional LIKE '%"+nome+"%'";
			Statement sta = con.getConexao().createStatement();
			ResultSet res = sta.executeQuery(sql);
			while(res.next()) {
				a.setNomeProfissional(res.getString("nomeProfissional"));
			}
			res.close();
			con.getConexao().close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return a;
	}
	public Agendamento gerarRelatorio6(){
		Agendamento a = new Agendamento();
		try {
			Conexao con = new Conexao();
			String sql = "SELECT COUNT(idAgendamento) AS 'totalAgendamentos' FROM agendamentos WHERE (porcDesconto != 0 AND convenio = 0)";
			Statement sta = con.getConexao().createStatement();
			ResultSet res = sta.executeQuery(sql);
			while (res.next()) {
				a.setIdAgendamento(res.getInt("totalAgendamentos"));
			}
			res.close();
			con.getConexao().close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return a;
	}
	public List<Agendamento> gerarRelatorio7() {
		List<Agendamento> l = new LinkedList<Agendamento>();
		try {
			Conexao con = new Conexao();
			String sql = "SELECT tipo, AVG(valorConsulta) AS 'mediaPreco', COUNT(idAgendamento) AS 'totalConsultas' FROM agendamentos GROUP BY tipo ORDER BY tipo";
			Statement sta = con.getConexao().createStatement();
			ResultSet res = sta.executeQuery(sql);
			while (res.next()) {
				Agendamento a = new Agendamento();
				a.setTipo(res.getString("tipo"));
				a.setValorConsulta(res.getDouble("mediaPreco"));
				a.setIdAgendamento(res.getInt("totalConsultas"));
				l.add(a);
			}
			res.close();
			con.getConexao().close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return l;
	}
	public List<Agendamento> gerarRelatorio08(){
		List<Agendamento> l = new LinkedList<Agendamento>();
		try {
			Conexao con = new Conexao();
			String sql = "SELECT nomeProfissional, SUM(valorConsulta) AS 'valorTotal' FROM agendamentos GROUP BY nomeProfissional HAVING SUM(valorConsulta) > 500 ORDER BY nomeProfissional";
			Statement sta = con.getConexao().createStatement();
			ResultSet res = sta.executeQuery(sql);
			while(res.next()) {
				Agendamento a = new Agendamento();
				a.setNomeProfissional(res.getString("nomeProfissional"));
				a.setValorConsulta(res.getDouble("valorTotal"));
				l.add(a);
			}
			res.close();
			con.getConexao().close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return l;
	}
	public Agendamento gerarRelatorio09(int mes) {
		Agendamento a = new Agendamento();
		try {
			Conexao con = new Conexao();
			String sql = "SELECT COUNT(*) AS 'qtdConsulta', SUM(valorConsulta - (valorConsulta * (porcDesconto/100))) as 'valorTotal' FROM agendamentos WHERE MONTH(dataAgendamento) =  '" + mes +"'";
			Statement sta = con.getConexao().createStatement();
			ResultSet res = sta.executeQuery(sql);
			while(res.next()) {
				a.setIdAgendamento(res.getInt("qtdConsulta"));
				a.setValorConsulta(res.getDouble("valorTotal"));
			}
			res.close();
			con.getConexao().close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return a;
	}
	public List<Agendamento> gerarRelatorio10(int mes){
		List<Agendamento> l = new LinkedList<Agendamento>();
		try {
			Conexao con = new Conexao();
			String sql = "SELECT nomeProfissional, COUNT(idAgendamento) as 'totalAgendamentos' FROM agendamentos WHERE MONTH(dataAgendamento) = " + mes + " GROUP BY nomeProfissional HAVING COUNT(idAgendamento) >= 10	";
			Statement sta = con.getConexao().createStatement();
			ResultSet res = sta.executeQuery(sql);
			while(res.next()) {
				Agendamento a = new Agendamento();
				a.setNomeProfissional(res.getString("nomeProfissional"));
				a.setIdAgendamento(res.getInt("totalAgendamentos"));
				l.add(a);
			}
			res.close();
			con.getConexao().close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return l;
	}
	
	
	
}
