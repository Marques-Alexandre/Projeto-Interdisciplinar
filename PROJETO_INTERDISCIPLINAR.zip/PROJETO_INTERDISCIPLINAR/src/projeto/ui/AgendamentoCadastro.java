package projeto.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.mariadb.jdbc.internal.com.send.parameters.LocalTimeParameter;

import projeto.db.AgendamentoDao;
import projeto.pojo.Agendamento;

import java.awt.FlowLayout;
import java.awt.CardLayout;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Hashtable;
import java.util.LinkedList;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import java.awt.SystemColor;

public class AgendamentoCadastro extends JFrame {

	
	private JPanel contentPane;
	private JTextField txtNome;
	private JTextField txtHorario;
	private JTextField txtDuracao;
	private JTextField txtCPF;
	private JTextField txtTelefone;
	private JTextField txtDataNascimento;
	private JTextField txtDataAgendamento;
	private JTextField txtValor;
	private JTextField txtDesconto;
	private JTextField txtNomeProfissional;
	private JComboBox cmbTipo;
	private JTextField txtConvenio;
	
	private int idAgendamento;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		Hashtable<String, LinkedList<Agendamento>> ed = new Hashtable<String, LinkedList<Agendamento>>();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AgendamentoCadastro frame = new AgendamentoCadastro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AgendamentoCadastro() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 769, 426);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("CADASTRO AGENDAMENTOS");
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
		lblNewLabel.setBounds(231, 23, 277, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNome.setBounds(27, 92, 127, 14);
		contentPane.add(lblNome);
		
		txtNome = new JTextField();
		txtNome.setBounds(27, 117, 217, 20);
		contentPane.add(txtNome);
		txtNome.setColumns(10);
		
		JLabel lblHorario = new JLabel("Horario:");
		lblHorario.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblHorario.setBounds(502, 92, 127, 14);
		contentPane.add(lblHorario);
		
		txtHorario = new JTextField();
		txtHorario.setBounds(502, 117, 86, 20);
		contentPane.add(txtHorario);
		txtHorario.setColumns(10);
		
		JLabel lblDuracao = new JLabel("Dura\u00E7\u00E3o:");
		lblDuracao.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblDuracao.setBounds(640, 92, 103, 14);
		contentPane.add(lblDuracao);
		
		txtDuracao = new JTextField();
		txtDuracao.setBounds(640, 117, 86, 20);
		contentPane.add(txtDuracao);
		txtDuracao.setColumns(10);
		
		JLabel lblCpf = new JLabel("CPF:");
		lblCpf.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblCpf.setBounds(27, 151, 103, 14);
		contentPane.add(lblCpf);
		
		txtCPF = new JTextField();
		txtCPF.setBounds(27, 176, 156, 20);
		contentPane.add(txtCPF);
		txtCPF.setColumns(10);
		
		JLabel lblTelefone = new JLabel("Telefone:");
		lblTelefone.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblTelefone.setBounds(27, 207, 127, 14);
		contentPane.add(lblTelefone);
		
		txtTelefone = new JTextField();
		txtTelefone.setBounds(27, 232, 156, 20);
		contentPane.add(txtTelefone);
		txtTelefone.setColumns(10);
		
		JLabel lblDataNascimento = new JLabel("Data Nascimento:");
		lblDataNascimento.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblDataNascimento.setBounds(27, 263, 127, 14);
		contentPane.add(lblDataNascimento);
		
		txtDataNascimento = new JTextField();
		txtDataNascimento.setBounds(27, 288, 103, 20);
		contentPane.add(txtDataNascimento);
		txtDataNascimento.setColumns(10);
		
		JLabel lblDataAgendamento = new JLabel("Data Agendamento:");
		lblDataAgendamento.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblDataAgendamento.setBounds(328, 92, 127, 14);
		contentPane.add(lblDataAgendamento);
		
		txtDataAgendamento = new JTextField();
		txtDataAgendamento.setBounds(328, 117, 127, 20);
		contentPane.add(txtDataAgendamento);
		txtDataAgendamento.setColumns(10);
		
		JLabel lblTipo = new JLabel("Tipo Consulta:");
		lblTipo.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblTipo.setBounds(328, 151, 127, 14);
		contentPane.add(lblTipo);
		
		cmbTipo = new JComboBox();
		cmbTipo.setModel(new DefaultComboBoxModel(new String[] {"Clinico Geral", "Dentista", "Fisioterapeuta", "Cardiologista", "Dermatologista"}));
		cmbTipo.setBounds(328, 174, 127, 22);
		contentPane.add(cmbTipo);
		
		JLabel lblValor = new JLabel("Valor:");
		lblValor.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblValor.setBounds(502, 151, 127, 14);
		contentPane.add(lblValor);
		
		txtValor = new JTextField();
		txtValor.setBounds(502, 176, 112, 20);
		contentPane.add(txtValor);
		txtValor.setColumns(10);
		
		JLabel lblDeDesconto = new JLabel("Desconto (%):");
		lblDeDesconto.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblDeDesconto.setBounds(328, 207, 127, 14);
		contentPane.add(lblDeDesconto);
		
		txtDesconto = new JTextField();
		txtDesconto.setBounds(328, 232, 86, 20);
		contentPane.add(txtDesconto);
		txtDesconto.setColumns(10);
		
		JLabel lblConvenio = new JLabel("Convenio?");
		lblConvenio.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblConvenio.setBounds(502, 207, 127, 14);
		contentPane.add(lblConvenio);
		
		JLabel lblNomeDoProfissional = new JLabel("Nome do Profissional:");
		lblNomeDoProfissional.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNomeDoProfissional.setBounds(328, 263, 127, 14);
		contentPane.add(lblNomeDoProfissional);
		
		txtNomeProfissional = new JTextField();
		txtNomeProfissional.setColumns(10);
		txtNomeProfissional.setBounds(328, 288, 217, 20);
		contentPane.add(txtNomeProfissional);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				salvar();
				Menu m = new Menu();
				m.setVisible(true);
				dispose();
			}
		});
		btnSalvar.setBounds(229, 353, 89, 23);
		contentPane.add(btnSalvar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.setBackground(UIManager.getColor("ScrollBar.thumbDarkShadow"));
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Menu m = new Menu();
				m.setVisible(true);
			}
		});
		btnCancelar.setBounds(443, 353, 89, 23);
		contentPane.add(btnCancelar);
		
		txtConvenio = new JTextField();
		txtConvenio.setBounds(502, 232, 86, 20);
		contentPane.add(txtConvenio);
		txtConvenio.setColumns(10);
		
	}
	private void salvar(){
		SimpleDateFormat formatoBR = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm");
		
		Agendamento a = new Agendamento();
		a.setNomePaciente(txtNome.getText());
		a.setCpf(txtCPF.getText());
		java.util.Date dataFormatada = null;
		try {
			dataFormatada = formatoBR.parse(txtDataNascimento.getText());
		} catch (Exception e) {
			e.printStackTrace();
		}
		a.setDataNasc(dataFormatada);
		a.setTelefone(txtTelefone.getText());
		java.util.Date dataFormatada2 = null;
		try {
			dataFormatada2 = formatoBR.parse(txtDataAgendamento.getText());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		a.setDataAgendamento(dataFormatada2);
		java.util.Date horaFormatada = null ;
		try {
			horaFormatada = formatoHora.parse(txtHorario.getText());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		a.setHorario(horaFormatada);
		a.setDuracao(Double.parseDouble(txtDuracao.getText()));
		a.setTipo(cmbTipo.getSelectedItem().toString());
		a.setValorConsulta(Double.parseDouble(txtValor.getText()));
		a.setPorcDesconto(Integer.parseInt(txtDesconto.getText()));
		a.setConvenio(Integer.parseInt(txtConvenio.getText()));
		a.setNomeProfissional(txtNomeProfissional.getText());
		a.setIdAgendamento(idAgendamento);
		
		AgendamentoDao adao = new AgendamentoDao();
		if (idAgendamento > 0) {
			adao.atualizar(a);
		}
		else {
			adao.inserir(a);
		}
		
		
		
	}
	public JComboBox getCmbTipo() {
		return cmbTipo;
	}

	public int getIdAgendamento() {
		return idAgendamento;
	}

	public void setIdAgendamento(int idAgendamento) {
		this.idAgendamento = idAgendamento;
		AgendamentoDao adao = new AgendamentoDao();
		Agendamento a = adao.consultar(idAgendamento);
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		txtDataAgendamento.setText(String.valueOf(sdf.format(a.getDataAgendamento())));
		txtHorario.setText(String.valueOf(a.getHorario()));
		txtDuracao.setText(String.valueOf(a.getDuracao()));
		txtCPF.setText(a.getCpf());
		txtNome.setText(a.getNomePaciente());
		txtTelefone.setText(a.getTelefone());
		txtDataNascimento.setText(String.valueOf(sdf.format(a.getDataNasc())));
		txtNomeProfissional.setText(a.getNomeProfissional());
		for (int i = 0; i < cmbTipo.getItemCount(); i++) {
			if (cmbTipo.getItemAt(i).toString().equals(a.getTipo())) {
				cmbTipo.setSelectedIndex(i);
				break;
			} 
		}
		txtValor.setText(String.valueOf(a.getValorConsulta()));
		txtDesconto.setText(String.valueOf(a.getPorcDesconto()));
		txtConvenio.setText(String.valueOf(a.getConvenio()));
	}
	
}
