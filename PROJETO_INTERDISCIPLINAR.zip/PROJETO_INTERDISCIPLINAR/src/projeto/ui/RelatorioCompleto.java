package projeto.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import projeto.db.AgendamentoDao;
import projeto.pojo.Agendamento;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;

public class RelatorioCompleto extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private DefaultTableModel dados = new DefaultTableModel() {
		@Override
		public boolean isCellEditable(int row, int col) {
			return false;
		}
	};

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RelatorioCompleto frame = new RelatorioCompleto();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RelatorioCompleto() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1226, 502);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 55, 1190, 366);
		contentPane.add(scrollPane);
		
		table = new JTable(dados);
		scrollPane.setViewportView(table);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Relatorios r = new Relatorios();
				r.setVisible(true);
				dispose();
			}
		});
		btnVoltar.setBounds(577, 432, 89, 23);
		contentPane.add(btnVoltar);
		
		JLabel lblRelCompleto = new JLabel("RELAT\u00D3RIO COMPLETO");
		lblRelCompleto.setHorizontalAlignment(SwingConstants.CENTER);
		lblRelCompleto.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		lblRelCompleto.setBounds(498, 11, 220, 33);
		contentPane.add(lblRelCompleto);
		
		listar();
	}
	public void listar() {
		dados.setColumnCount(0);
		dados.setRowCount(0);
		dados.addColumn("ID");
		dados.addColumn("Data Agendamento");
		dados.addColumn("Horario");
		dados.addColumn("Dura��o");
		dados.addColumn("CPF");
		dados.addColumn("Nome Paciente");
		dados.addColumn("Telefone");
		dados.addColumn("Data de Nascimento");
		dados.addColumn("Nome do Profissional");
		dados.addColumn("Tipo");
		dados.addColumn("Valor");
		dados.addColumn("% de Desconto");
		dados.addColumn("Convenio");
		
		AgendamentoDao adao = new AgendamentoDao();
		List<Agendamento> lista = adao.listar();
		for (Agendamento a : lista) {
			dados.addRow(a.getVetor());
		}
	}
}
