package projeto.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import projeto.db.AgendamentoDao;
import projeto.pojo.Agendamento;

import java.awt.SystemColor;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.awt.event.ActionEvent;

public class Relatorio02 extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private DefaultTableModel dados = new DefaultTableModel() {
		@Override
		public boolean isCellEditable(int row, int col) {
			return false;
		}
	};

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Relatorio02 frame = new Relatorio02();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Relatorio02() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 950, 505);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(28, 34, 882, 380);
		contentPane.add(scrollPane);
		
		table = new JTable(dados);
		scrollPane.setViewportView(table);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Relatorios r = new Relatorios();
				r.setVisible(true);
				dispose();
			}
		});
		btnVoltar.setBounds(448, 425, 89, 23);
		contentPane.add(btnVoltar);
		
		consultar();
	}
	private void consultar() {
		dados.setColumnCount(0);
		dados.setRowCount(0);
		dados.addColumn("Nome do Profissional");
		dados.addColumn("Data Agendamento");
		dados.addColumn("Hor�rio");
		dados.addColumn("Dura��o");
		dados.addColumn("Nome Paciente");
		
		AgendamentoDao adao = new AgendamentoDao();
		DateFormat dtBR = new SimpleDateFormat("dd/MM/yyyy");
		String dataInicio = JOptionPane.showInputDialog("Data in�cio: ");
		String dataFinal = JOptionPane.showInputDialog("Data final: ");
		java.util.Date dataIni = null;
		try {
			dataIni = dtBR.parse(dataInicio);
		} catch (ParseException e) {

			e.printStackTrace();
		}
		java.util.Date datafim = null;
		try {
			datafim = dtBR.parse(dataFinal);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		List<Agendamento> agendamentos = adao.gerarRelatorio2(dataIni, datafim);
		for (Agendamento a : agendamentos) {
			dados.addRow(a.getVetorRelatorio02());
			
		}
		
	}
}
