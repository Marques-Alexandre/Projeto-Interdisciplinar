package projeto.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import projeto.db.AgendamentoDao;
import projeto.pojo.Agendamento;

import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

public class Relatorio01 extends JFrame {
	
	
	private JPanel contentPane;
	private JTable table;
	private DefaultTableModel dados = new DefaultTableModel() {
		@Override
		public boolean isCellEditable(int row, int col) {
			return false;
		}
	};
	private JButton btnNewButton;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Relatorio01 frame = new Relatorio01();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Relatorio01() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 843, 421);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 24, 807, 302);
		contentPane.add(scrollPane);
		
		table = new JTable(dados);
		scrollPane.setViewportView(table);
		
		btnNewButton = new JButton("Voltar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Relatorios r = new Relatorios();
				r.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(362, 337, 89, 23);
		contentPane.add(btnNewButton);
		
		consultar();
	}
	private void consultar(){
		dados.setColumnCount(0);
		dados.setRowCount(0);
		dados.addColumn("Nome do Profissional");
		dados.addColumn("Data Agendamento");
		dados.addColumn("Hor�rio");
		dados.addColumn("Dura��o");
		dados.addColumn("Nome Paciente");
		dados.addColumn("Valor");
		
		AgendamentoDao adao = new AgendamentoDao();
		Agendamento a = new Agendamento();
		String nomeProfissional = JOptionPane.showInputDialog("Nome do Profissional: ").toString();
		a.setNomeProfissional(nomeProfissional);
		Hashtable<String, LinkedList<Agendamento>> ed = new Hashtable<String, LinkedList<Agendamento>>();
		LinkedList<Agendamento> lista = (LinkedList<Agendamento>) adao.gerarRelatorio1(nomeProfissional);
		
			for (Agendamento ag : lista) {
				ed.put(ag.getNomeProfissional(), new LinkedList<Agendamento>());
				ed.get(ag.getNomeProfissional()).add(ag);
				if (ed.containsKey(ag.getNomeProfissional())) {
					dados.addRow(ag.getVetorRelatorio01());
				}
				else {
					JOptionPane.showMessageDialog(null, "Profissional n�o cadastrado.");
				}
		}
			
	}
		
}
