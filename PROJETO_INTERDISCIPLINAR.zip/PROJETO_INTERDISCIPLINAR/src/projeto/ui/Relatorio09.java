package projeto.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import projeto.db.AgendamentoDao;
import projeto.pojo.Agendamento;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

public class Relatorio09 extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private DefaultTableModel dados = new DefaultTableModel() {
		@Override
		public boolean isCellEditable(int row, int col) {
			return false;
		}
	};

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Relatorio09 frame = new Relatorio09();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Relatorio09() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 699, 314);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 24, 641, 210);
		contentPane.add(scrollPane);
		
		table = new JTable(dados);
		scrollPane.setViewportView(table);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Relatorios r = new Relatorios();
				r.setVisible(true);
				dispose();
			}
		});
		btnVoltar.setBounds(295, 245, 89, 23);
		contentPane.add(btnVoltar);
		
		consultar();
	}
	private void consultar() {
		dados.setColumnCount(0);
		dados.setRowCount(0);
		dados.addColumn("Quantidade de consultas");
		dados.addColumn("Valor total");
		
		AgendamentoDao adao = new AgendamentoDao();
		int mes = Integer.parseInt(JOptionPane.showInputDialog("M�s: "));
		
		Agendamento a = adao.gerarRelatorio09(mes);
		dados.addRow(a.getVetorRelatorio09());
	}

}
