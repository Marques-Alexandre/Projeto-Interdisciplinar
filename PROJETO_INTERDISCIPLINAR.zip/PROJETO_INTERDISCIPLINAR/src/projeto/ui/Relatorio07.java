package projeto.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import projeto.db.AgendamentoDao;
import projeto.pojo.Agendamento;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

public class Relatorio07 extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private DefaultTableModel dados = new DefaultTableModel() {
		@Override
		public boolean isCellEditable(int row, int col) {
			return false;
		}
	};

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Relatorio07 frame = new Relatorio07();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Relatorio07() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 655, 394);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 24, 619, 282);
		contentPane.add(scrollPane);
		
		table = new JTable(dados);
		scrollPane.setViewportView(table);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Relatorios r = new Relatorios();
				r.setVisible(true);
				dispose();
			}
		});
		btnVoltar.setBounds(275, 317, 89, 23);
		contentPane.add(btnVoltar);
		
		consultar();
	}
	private void consultar() {
		dados.setColumnCount(0);
		dados.setRowCount(0);
		dados.addColumn("Tipo de Profissional");
		dados.addColumn("M�dia de Pre�os");
		dados.addColumn("Total de Consultas");
		
		AgendamentoDao adao = new AgendamentoDao();
		List<Agendamento> agendamentos = adao.gerarRelatorio7();
		for (Agendamento a : agendamentos) {
			dados.addRow(a.getVetorRelatorio07());
		}
		
		
		
	}

}
