package projeto.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import projeto.db.AgendamentoDao;
import projeto.pojo.Agendamento;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

public class Consultar extends JFrame {

	private JPanel contentPane;
	private JTextField txtIDConsulta;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Consultar frame = new Consultar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Consultar() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 441, 257);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ID Agendamento para consulta:");
		lblNewLabel.setBounds(22, 83, 189, 14);
		contentPane.add(lblNewLabel);
		
		txtIDConsulta = new JTextField();
		txtIDConsulta.setBounds(221, 80, 86, 20);
		contentPane.add(txtIDConsulta);
		txtIDConsulta.setColumns(10);
		
		JButton btnConsultar = new JButton("Consultar");
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				consultar();
				//ResultadoConsulta rc = new ResultadoConsulta();
				//rc.setVisible(true);
				//dispose();
			}
		});
		btnConsultar.setBounds(89, 163, 89, 23);
		contentPane.add(btnConsultar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Menu m = new Menu();
				m.setVisible(true);
				dispose();
			}
		});
		btnCancelar.setBounds(234, 163, 89, 23);
		contentPane.add(btnCancelar);
		
		JLabel lblConsultar = new JLabel("Consultar Agendamento");
		lblConsultar.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		lblConsultar.setBounds(127, 11, 189, 14);
		contentPane.add(lblConsultar);
	}
	public void consultar() {
		AgendamentoDao adao = new AgendamentoDao();
		//l.add(adao.consultar(Integer.parseInt(txtIDConsulta.getText())));
	
		JOptionPane.showMessageDialog(null,adao.consultar(Integer.parseInt(txtIDConsulta.getText().toString())));
	}

	public JTextField getTxtIDConsulta() {
		return txtIDConsulta;
	}
}
