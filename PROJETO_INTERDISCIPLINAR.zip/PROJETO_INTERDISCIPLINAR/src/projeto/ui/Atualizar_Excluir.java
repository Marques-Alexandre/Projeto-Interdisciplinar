package projeto.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import projeto.db.AgendamentoDao;
import projeto.pojo.Agendamento;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

public class Atualizar_Excluir extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private DefaultTableModel dados = new DefaultTableModel() {
				@Override
				public boolean isCellEditable(int row, int col) {
					return false;
				}
			};

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Atualizar_Excluir frame = new Atualizar_Excluir();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Atualizar_Excluir() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1210, 496);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 1184, 388);
		contentPane.add(scrollPane);
		
		table = new JTable(dados);
		scrollPane.setViewportView(table);
		
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				atualizar();
			}
		});
		btnAlterar.setBounds(387, 423, 89, 23);
		contentPane.add(btnAlterar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				excluir();
			}
		});
		btnExcluir.setBounds(538, 423, 89, 23);
		contentPane.add(btnExcluir);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Menu m = new Menu();
				m.setVisible(true);
				dispose();
			}
		});
		btnVoltar.setBounds(758, 423, 89, 23);
		contentPane.add(btnVoltar);
		
		listar();
	}
	public void listar() {
		dados.setColumnCount(0);
		dados.setRowCount(0);
		dados.addColumn("ID");
		dados.addColumn("Data Agendamento");
		dados.addColumn("Horario");
		dados.addColumn("Dura��o");
		dados.addColumn("CPF");
		dados.addColumn("Nome Paciente");
		dados.addColumn("Telefone");
		dados.addColumn("Data de Nascimento");
		dados.addColumn("Nome do Profissional");
		dados.addColumn("Tipo");
		dados.addColumn("Valor");
		dados.addColumn("% de Desconto");
		dados.addColumn("Convenio");
		
		AgendamentoDao adao = new AgendamentoDao();
		List<Agendamento> lista = adao.listar();
		for (Agendamento a : lista) {
			dados.addRow(a.getVetor());
		}
	}
	private void atualizar() {
		int id = Integer.parseInt(dados.getValueAt(table.getSelectedRow(), 0).toString());
		AgendamentoCadastro ag = new AgendamentoCadastro();
		ag.setIdAgendamento(id);
		ag.setVisible(true);
		dispose();
	}
	private void excluir() {
		int resposta = JOptionPane.showConfirmDialog(null, "Confirma a exclus�o?", "Exclus�o", JOptionPane.YES_NO_OPTION);
		if (resposta == JOptionPane.YES_OPTION) {
			AgendamentoDao adao = new AgendamentoDao();
			Agendamento a = new Agendamento();
			a.setIdAgendamento(Integer.parseInt(dados.getValueAt(table.getSelectedRow(), 0).toString()));
			adao.excluir(a);
			listar();
		}
	}
}
