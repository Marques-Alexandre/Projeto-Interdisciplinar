package projeto.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import projeto.db.AgendamentoDao;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

public class Relatorios extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Relatorios frame = new Relatorios();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Relatorios() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 481, 381);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnrelCompleto = new JButton("Relatorio Completo");
		btnrelCompleto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RelatorioCompleto rc = new RelatorioCompleto();
				rc.setVisible(true);
				dispose();
			}
		});
		btnrelCompleto.setBounds(163, 267, 149, 23);
		contentPane.add(btnrelCompleto);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Menu m = new Menu();
				m.setVisible(true);
				dispose();
			}
		});
		btnVoltar.setBounds(331, 308, 89, 23);
		contentPane.add(btnVoltar);
		
		JButton btnRelatorio01 = new JButton("Relatorio 01");
		btnRelatorio01.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Relatorio01 r = new Relatorio01();
				r.setVisible(true);
				dispose();
				
			}
		});
		btnRelatorio01.setBounds(24, 29, 149, 23);
		contentPane.add(btnRelatorio01);
		
		JButton btnRelatorio02 = new JButton("Relatorio 02");
		btnRelatorio02.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Relatorio02 r = new Relatorio02();
				r.setVisible(true);
				dispose();
			}
		});
		btnRelatorio02.setBounds(271, 29, 149, 23);
		contentPane.add(btnRelatorio02);
		
		JButton btnRelatorio03 = new JButton("Relatorio 03");
		btnRelatorio03.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Relatorio03 r = new Relatorio03();
				r.setVisible(true);
				dispose();
			}
		});
		btnRelatorio03.setBounds(24, 74, 149, 23);
		contentPane.add(btnRelatorio03);
		
		JButton btnRelatorio04 = new JButton("Relatorio 04");
		btnRelatorio04.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Relatorio04 r = new Relatorio04();
				r.setVisible(true);
				dispose();
			}
		});
		btnRelatorio04.setBounds(271, 74, 149, 23);
		contentPane.add(btnRelatorio04);
		
		JButton btnRelatorio05 = new JButton("Relatorio 05");
		btnRelatorio05.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Relatorio05 r = new Relatorio05();
				r.setVisible(true);
				dispose();
			}
		});
		btnRelatorio05.setBounds(24, 120, 149, 23);
		contentPane.add(btnRelatorio05);
		
		JButton btnRelatorio06 = new JButton("Relatorio 06");
		btnRelatorio06.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Relatorio06 r = new Relatorio06();
				r.setVisible(true);
				dispose();
			}
		});
		btnRelatorio06.setBounds(271, 120, 149, 23);
		contentPane.add(btnRelatorio06);
		
		JButton btnRelatorio07 = new JButton("Relatorio 07");
		btnRelatorio07.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Relatorio07 r = new Relatorio07();
				r.setVisible(true);
				dispose();
			}
		});
		btnRelatorio07.setBounds(24, 165, 149, 23);
		contentPane.add(btnRelatorio07);
		
		JButton btnRelatorio08 = new JButton("Relatorio 08");
		btnRelatorio08.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Relatorio08 r = new Relatorio08();
				r.setVisible(true);
				dispose();
			}
		});
		btnRelatorio08.setBounds(271, 165, 149, 23);
		contentPane.add(btnRelatorio08);
		
		JButton btnRelatorio09 = new JButton("Relatorio 09");
		btnRelatorio09.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Relatorio09 r = new Relatorio09();
				r.setVisible(true);
				dispose();
			}
		});
		btnRelatorio09.setBounds(24, 212, 149, 23);
		contentPane.add(btnRelatorio09);
		
		JButton btnRelatorio10 = new JButton("Relatorio 10");
		btnRelatorio10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Relatorio10 r = new Relatorio10();
				r.setVisible(true);
				dispose();
			}
		});
		btnRelatorio10.setBounds(271, 212, 149, 23);
		contentPane.add(btnRelatorio10);
	}
}
