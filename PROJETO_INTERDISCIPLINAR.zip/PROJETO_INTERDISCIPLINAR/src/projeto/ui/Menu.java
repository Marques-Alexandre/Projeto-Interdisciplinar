package projeto.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;

public class Menu extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu frame = new Menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Menu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 755, 392);
		contentPane = new JPanel();
		contentPane.setBackground(UIManager.getColor("MenuBar.shadow"));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("SISTEMA DE AGENDAMENTOS");
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(218, 29, 322, 14);
		contentPane.add(lblNewLabel);
		
		JButton btnCadastrar = new JButton("Cadastrar Agendamento");
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AgendamentoCadastro ag = new AgendamentoCadastro();
				ag.setVisible(true);
				dispose();
			}
		});
		btnCadastrar.setBounds(283, 101, 180, 23);
		contentPane.add(btnCadastrar);
		
		JButton btnAtualizar = new JButton("Atualizar / Excluir");
		btnAtualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				atualizarExcluir();
				
			}
		});
		btnAtualizar.setBounds(283, 204, 182, 23);
		contentPane.add(btnAtualizar);
		
		JButton btnConsultar = new JButton("Consultar Agendamento");
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				consultar();
			}
		});
		btnConsultar.setBounds(283, 150, 180, 23);
		contentPane.add(btnConsultar);
		
		JButton btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnSair.setBounds(568, 293, 89, 23);
		contentPane.add(btnSair);
		
		JButton btnNewButton = new JButton("Gerar Relat\u00F3rios");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Relatorios r = new Relatorios();
				r.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(305, 253, 139, 23);
		contentPane.add(btnNewButton);
	}
	private void atualizarExcluir() {
		Atualizar_Excluir rc = new Atualizar_Excluir();
		rc.setVisible(true);
		dispose();
	}
	private void consultar() {
		Consultar con = new Consultar();
		con.setVisible(true);
		dispose();
	}
}
