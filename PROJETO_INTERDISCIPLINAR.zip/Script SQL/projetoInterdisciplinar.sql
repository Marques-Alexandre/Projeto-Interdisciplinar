CREATE DATABASE bdagendamento;
USE bdagendamento;

CREATE TABLE agendamentos (
	idAgendamento INT(6) AUTO_INCREMENT,
    dataAgendamento DATE NOT NULL,
    horario TIME NOT NULL,
	duracao FLOAT(8) DEFAULT 1,
    cpf VARCHAR(11) NOT NULL,
    nomePaciente VARCHAR(50) NOT NULL,
    telefone VARCHAR(20),
    dataNasc DATE,
    nomeProfissional VARCHAR(50) NOT NULL,
    tipo VARCHAR(30) NOT NULL,
    valorConsulta FLOAT(8) DEFAULT 200.00,
    porcDesconto INT(4),
    convenio INT(1) DEFAULT 0,
    PRIMARY KEY (idAgendamento)
);

-- Inserindo 10 registros no Banco de Dados.
INSERT INTO agendamentos(dataAgendamento, horario, duracao, cpf, nomePaciente, telefone, dataNasc, nomeProfissional, tipo,
valorConsulta, porcDesconto, convenio)
VALUES ('2020-07-17','14:00','1', '15898732601', 'Carlos', '98827-6978', '1994-01-15', 'Flavio', 'Dentista', 250.00, 0, 0);

INSERT INTO agendamentos(dataAgendamento, horario, duracao, cpf, nomePaciente, telefone, dataNasc, nomeProfissional, tipo,
valorConsulta, porcDesconto, convenio)
VALUES ('2020-07-23','10:00','2', '65987425633', 'Maria', '98794-5522', '1999-08-27', 'Pedro', 'Clínico Geral', 190.00, 0, 1 );

INSERT INTO agendamentos(dataAgendamento, horario, cpf, nomePaciente, telefone, dataNasc, nomeProfissional, tipo,
valorConsulta, porcDesconto, convenio)
VALUES ('2020-07-28','11:30', '19874539677', 'Ana Flavia', '99887-1514', '2000-03-07', 'Paulo', 'Fisioterapeuta', 120.00, 0, 0 );

INSERT INTO agendamentos(dataAgendamento, horario, cpf, nomePaciente, telefone, dataNasc, nomeProfissional, tipo,
valorConsulta, porcDesconto, convenio)
VALUES ('2020-07-29','11:30', '19874539666', 'José augusto', '99887-1516', '2000-03-27', 'Paulo', 'Fisioterapeuta', 120.00, 0, 0 );

INSERT INTO agendamentos(dataAgendamento, horario, cpf, nomePaciente, telefone, dataNasc, nomeProfissional, tipo,
valorConsulta, porcDesconto, convenio)
VALUES ('2020-08-15','13:30', '19854165879', 'Cleyton', '98549-6514', '2020-04-15', 'Jorge', 'Dermatlogista', 120, 20, 0 );

INSERT INTO agendamentos(dataAgendamento, horario, cpf, nomePaciente, telefone, dataNasc, nomeProfissional, tipo,
valorConsulta, porcDesconto, convenio)
VALUES ('2020-09-01','14:30', '18541232568', 'Lazin', '98425-4780', '2003-07-29', 'Dawnton', 'Cardiologista', 80, 5, 1 );


INSERT INTO agendamentos(dataAgendamento, horario, cpf, nomePaciente, telefone, dataNasc, nomeProfissional, tipo,
valorConsulta, porcDesconto, convenio)
VALUES ('2020-09-19','09:30', '12312377756', 'José Flavio', '94744-1919', '1976-02-13', 'Paulo', 'Fisioterapeuta', 150.00, 10, 1 );

INSERT INTO agendamentos(dataAgendamento, horario, cpf, nomePaciente, telefone, dataNasc, nomeProfissional, tipo,
valorConsulta, porcDesconto, convenio)
VALUES ('2020-09-19','09:30', '14589753953', 'Marcela', '95630-8589', '2004-12-25', 'Flavio', 'Dentista', 200.00, 0, 0 );

INSERT INTO agendamentos(dataAgendamento, horario, cpf, nomePaciente, telefone, dataNasc, nomeProfissional, tipo,
valorConsulta, porcDesconto, convenio)
VALUES ('2020-08-02','11:30', '17826454118', 'Fabricia', '98827-4570', '1990-02-14', 'Jorge', 'Dermatologista', 149.90, 0, 0 );

INSERT INTO agendamentos(dataAgendamento, horario, cpf, nomePaciente, telefone, dataNasc, nomeProfissional, tipo,
valorConsulta, porcDesconto, convenio)
VALUES ('2020-07-19','08:30', '87587587588', 'Valdivino', '91210-6666', '1958-06-13', 'Dawton', 'Cardiologista', 250.00, 0, 1 );

select * from agendamentos;

-- SELECTS---
-- Exercício 01:
SELECT dataAgendamento as 'Data', duracao as 'Duração', nomePaciente AS 'Paciente',
valorConsulta AS 'Valor Consulta' FROM agendamentos WHERE nomeProfissional = '?'
ORDER BY idAgendamento DESC;

-- Exercício 02:
SELECT nomeProfissional as 'Nome Profissional', dataAgendamento as 'Data Agendamento',
horario as 'Horário', duracao as 'Duração', nomePaciente as 'Nome Paciente' FROM agendamentos
WHERE (dataAgendamento >= '?' AND dataAgendamento <= '?') ORDER BY nomeProfissional;

-- Exercício 03:
SELECT nomeProfissional as 'Nome Profissional', dataAgendamento as 'Data Agendamento',
horario as 'Horário', duracao as 'Duração', nomePaciente as 'Nome Paciente' FROM agendamentos
WHERE tipo = '?' AND dataAgendamento >= '?' AND dataAgendamento <= '?'
ORDER BY dataAgendamento, Horario ASC;

-- Exercício 04:
SELECT cpf as 'CPF', nomePaciente as 'Nome Paciente', telefone as 'Telefone', dataNasc as 'Data Nascimento', 
TIMESTAMPDIFF(YEAR, dataNasc, NOW()) AS 'idade' FROM agendamentos WHERE MONTH(dataNasc) = '?';
 
 -- Exercício 05:
 SELECT nomeProfissional AS 'Profissional' FROM agendamentos WHERE nomeProfissional LIKE '%?%' ORDER BY nomeProfissional DESC; 
 
 -- Exercício 06:
 SELECT COUNT(idAgendamento) as 'Total Agendamentos' FROM agendamentos WHERE (porcDesconto != 0 AND convenio = 0);

-- Exercicio 07:
SELECT  tipo AS 'Tipo Profissional', COUNT(idAgendamento) AS 'Quantidade de consultas', AVG(valorConsulta) AS 'Media preço'   FROM agendamentos GROUP BY tipo ORDER BY tipo ASC;

-- Exercicio 08:
SELECT nomeProfissional, SUM(valorConsulta) AS 'Valor total' FROM agendamentos GROUP BY nomeProfissional HAVING SUM(valorConsulta) > 500 ORDER BY nomeProfissional ASC;

-- Exercicio 09:
SELECT COUNT(*) as 'Total de Agendamentos', SUM(valorConsulta - (valorConsulta * (porcDesconto / 100))) as 'Valor Total Agendamentos'
FROM agendamentos WHERE MONTH(dataAgendamento) = '?';
	
-- Exercicio 10:

SELECT nomeProfissional AS 'Profissional', COUNT(idAgendamento) AS 'Total Agendamentos' FROM agendamentos WHERE MONTH(dataAgendamento) = '?' GROUP BY nomeProfissional  HAVING COUNT(idAgendamento) >= 10; 

SELECT * FROM agendamentos;

